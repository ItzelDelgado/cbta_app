<div class="relative overflow-x-auto">
    <table id="solicitudesTable" class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                    <th scope="col" class="px-6 py-3">
                        ID
                    </th>
                <?php endif; ?>
                <th scope="col" class="px-6 py-3">
                    Hospital
                </th>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                    <th scope="col" class="px-6 py-3">
                        Modificar
                    </th>
                <?php endif; ?>
                <th scope="col" class="px-6 py-3">
                    Fecha y hora solicitud
                </th>
                <th scope="col" class="px-6 py-3">
                    Fecha y hora entrega
                </th>
                <th scope="col" class="px-6 py-3">
                    Estado
                </th>

                <th scope="col" class="px-6 py-3">
                    Detalles
                </th>

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                    <th scope="col" class="px-6 py-3">
                        Remisión
                    </th>
                <?php endif; ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                    <th scope="col" class="px-6 py-3">
                        Lote
                    </th>
                <?php endif; ?>

            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr
                    class="
                    <?php if($solicitud->read_at): ?> bg-white
                    <?php else: ?>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->roles->contains('name', 'Admin')): ?>
                                bg-[#fde047ab]
                            <?php else: ?>
                                bg-white <?php endif; ?>
<?php else: ?>
bg-white
                        <?php endif; ?>
                    <?php endif; ?>
                    border-b dark:bg-gray-800 dark:border-gray-700
                ">
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                            <?php echo e($solicitud->id); ?>

                        </th>
                    <?php endif; ?>
                    <td class="px-6 py-4">
                        <?php echo e($solicitud->user->hospital->name); ?>

                    </td>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <td class="px-6 py-4">
                            <!--[if BLOCK]><![endif]--><?php if($solicitud->is_aprobada == 'Pendiente'): ?>
                                <div class="flex items-center">
                                    <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                                        href="<?php echo e(route('admin.solicitudes.edit', $solicitud)); ?>"
                                        wire:click.prevent="readSolicitudEdit('<?php echo e($solicitud->id); ?>')">
                                        <i class="fa-solid fa-pen pr-1"></i> Aprobar
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="flex items-center"></div>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                    <?php endif; ?>
                    <td class="px-6 py-4">
                        <?php echo e($solicitud->created_at); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($solicitud->solicitud_detail->fecha_hora_entrega); ?>

                    </td>
                    <td class="px-6 py-4">
                        <!--[if BLOCK]><![endif]--><?php if($solicitud->is_aprobada == 'Aprobada'): ?>
                            <div class="flex items-center">
                                <div class="h-2.5 w-2.5 rounded-full bg-green-500 me-2"></div> Aprobada
                            </div>
                        <?php elseif($solicitud->is_aprobada == 'No Aprobada'): ?>
                            <div class="flex items-center">
                                <div class="h-2.5 w-2.5 rounded-full bg-red-500 me-2"></div> No Aprobada
                            </div>
                        <?php elseif($solicitud->is_aprobada == 'Pendiente'): ?>
                            <div class="flex items-center">
                                <div class="h-2.5 w-2.5 rounded-full bg-azul-prodifem me-2"></div> Pendiente
                            </div>
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </td>
                    <td class="px-6 py-4">
                        <div class="flex items-center">
                            <button
                                class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                                wire:click.prevent="readSolicitud('<?php echo e($solicitud->id); ?>')">
                                <i class="fa-solid fa-eye pr-1"></i> Ver
                            </button>
                        </div>
                    </td>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <td class="px-6 py-4">
                            <!--[if BLOCK]><![endif]--><?php if(isset($solicitud->solicitud_aprobada)): ?>
                                <?php echo e($solicitud->solicitud_aprobada->id); ?>

                            <?php else: ?>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <td class="px-6 py-4">
                            <!--[if BLOCK]><![endif]--><?php if(isset($solicitud->solicitud_aprobada)): ?>
                                <?php echo e($solicitud->solicitud_aprobada->lote); ?>

                            <?php else: ?>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
    <div class="mt-4">
        <?php echo e($solicitudes->links()); ?>

    </div>
</div>




<?php /**PATH C:\laragon\www\cbta_app\resources\views/livewire/solicituds.blade.php ENDPATH**/ ?>