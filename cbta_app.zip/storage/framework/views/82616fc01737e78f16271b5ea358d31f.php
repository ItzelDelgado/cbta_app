
<img class="w-full" src="<?php echo e(asset('img/Centro Biotecnologico de Terapias Avanzadas.png')); ?>" alt="">
<?php /**PATH C:\laragon\www\cbta_app\resources\views/components/application-mark.blade.php ENDPATH**/ ?>