<?php
    // Incluye manualmente el archivo helpers.php
    require_once app_path('Helpers/helpers.php');

    $aguaCalculada = 0; // Inicializa la variable

    foreach ($inputs as $input) {
        if ($input->category_id == 7) {
            $valor = renderInputMLSection($input->input_id, $inputs_solicitud);
            // Limpia el valor para que sea numérico
            $valor = str_replace(',', '', $valor); // Elimina comas (u otros separadores)
            $aguaCalculada = floatval($valor); // Convierte el valor a número flotante
        }
    }
    $bolsaSeleccionadaId = null;
    $volumenTotalFinal = $solicitud->solicitud_detail->volumen_total_final;

    // Filtrar bolsas Eva que pueden contener el volumen total
    $bolsaSeleccionada = $inputs
        ->filter(function ($input) use ($volumenTotalFinal) {
            return $input->category_id == 6 && $input->presentacion_ml >= $volumenTotalFinal; // Bolsas válidas
        })
        ->sortBy('presentacion_ml') // Ordenar por tamaño de presentación ascendente
        ->first(); // Tomar la más pequeña que sea suficiente

    $bolsaSeleccionadaId = $bolsaSeleccionada ? $bolsaSeleccionada->input_id : null;

    $loteBolsaEva = $bolsaSeleccionada ? $bolsaSeleccionada->lote : null;
    $caducidadBolsaEva = $bolsaSeleccionada ? $bolsaSeleccionada->caducidad : null;
?>

<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="mt-2">
        <h1 class="text-2xl font-medium text-gray-800">Detalles de solicitud</h1>
    </div>

    

    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin|Cliente')): ?>

        <div class="flex mb-8 justify-end items-baseline">
            <div class="mt-4">
                <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                    href="<?php echo e(route('admin.solicitudes.solicitud', $solicitud)); ?>" target="_blank">Solicitud</a>
            </div>
            <?php if($solicitud->is_aprobada == 'Aprobada'): ?>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                    <div class="mt-4">
                        <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                            href="<?php echo e(route('admin.solicitudes.ordenPreparacion', $solicitud)); ?>" target="_blank">Orden de
                            preparación</a>
                    </div>
                    <div class="mt-5">
                        <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                            href="<?php echo e(route('admin.solicitudes.remision', $solicitud)); ?>" target="_blank">Remisión</a>
                    </div>
                    <div class="mt-5">
                        <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                            href="<?php echo e(route('admin.solicitudes.envio', $solicitud)); ?>" target="_blank">Envío</a>
                    </div>
                    <div class="mt-5">
                        <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                            href="<?php echo e(route('admin.solicitudes.etiqueta', $solicitud)); ?>" target="_blank">Etiqueta</a>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="flex items-center">
                    <!-- Contenido para solicitudes no aprobadas -->
                </div>
            <?php endif; ?>
        </div>

    <?php endif; ?>


    

    <div class="flex flex-col items-center">
        <div class="mt-2 mb-4">
            <h1 class="text-2xl font-medium text-gray-800 text-center">SOLICITUD DE NUTRICIÓN PARENTERAL</h1>
        </div>
        <?php if($solicitud->solicitud_detail->sobrellenado_ml !== null): ?>
            <p>El usuario ingreso un valor en el campo de sobrellenado:
                <?php echo e($solicitud->solicitud_detail->sobrellenado_ml); ?> </p>
            <?php if($solicitud->solicitud_detail->volumen_total !== null): ?>
                <p>Volumen total ingresado por el usuario: <?php echo e($solicitud->solicitud_detail->volumen_total); ?></p>
                <p>Suma de elementos ingresados por el usuario en mL:
                    <?php echo e(number_format($solicitud->solicitud_detail->suma_volumen, 3, '.', '')); ?>

                <p>Agua calculada:
                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 7): ?>
                            <?php echo e(number_format(renderInputMLSection($input->input_id, $inputs_solicitud), 3, '.', '')); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <?php if($solicitud->solicitud_detail->volumen_total < $solicitud->solicitud_detail->suma_volumen): ?>
                    <h2 class="text-red-500">El volumen total en mL que ingresó el usuario es menor a la suma total en mL
                        de los elementos calculada. <br>
                        Verifica los valores, el cálculo del agua es negativo.</h2>
                <?php endif; ?>
                <?php if(60 < ($aguaCalculada / $solicitud->solicitud_detail->volumen_total) * 100): ?>
                    <h2 class="text-red-500">El volumen total en mL que se genero es mayor al 60% del volumen total de la
                        mezcla. <br>
                        Reajusta el volumen total para generar un nuevo valor para el agua.</h2>
                <?php endif; ?>
                <p>Volumen total ingresado por el usuario con sobrellenado:
                    <?php echo e(number_format($solicitud->solicitud_detail->volumen_total_final, 2, '.', '')); ?></p>
                <p>Suma total de los elementos ingresados por el usuario con sobrellenado:
                    <?php echo e(number_format($solicitud->solicitud_detail->suma_volumen_sobrellenado, 3, '.', '')); ?></p>
                <p>Agua calculada con sobrellenado:
                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 7): ?>
                            <?php echo e(number_format(renderInputMLSobrellenadoSection($input->input_id, $inputs_solicitud), 3, '.', '')); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            <?php else: ?>
                <p>El usuario no ingreso un volumen total.</p>
                <p>Suma de elementos ingresados por el usuario en mL:
                    <?php echo e(number_format($solicitud->solicitud_detail->suma_volumen, 3, '.', '')); ?></p>
                <p>Suma de elementos ingresados por el usuario en mL con sobrellenado:
                    <?php echo e(number_format($solicitud->solicitud_detail->suma_volumen_sobrellenado, 3, '.', '')); ?></p>
            <?php endif; ?>
        <?php else: ?>
            <p>El usuario no ingresó un valor en sobrellenado.</p>
            <?php if($solicitud->solicitud_detail->volumen_total !== null): ?>
                <p>Volumen total ingresado por el usuario: <?php echo e($solicitud->solicitud_detail->volumen_total); ?></p>
                <p>Suma de elementos ingresados por el usuario en mL:
                    <?php echo e(number_format($solicitud->solicitud_detail->suma_volumen, 3, '.', '')); ?></p>
                <p>Agua calculada:
                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 7): ?>
                            <?php echo e(number_format(renderInputMLSection($input->input_id, $inputs_solicitud), 3, '.', '')); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <?php if($solicitud->solicitud_detail->volumen_total < $solicitud->solicitud_detail->suma_volumen): ?>
                    <h2 class="text-red-500">El volumen total en mL que ingresó el usuario es menor a la suma total en mL
                        de los elementos calculada. <br>
                        Verifica los valores, el cálculo del agua es negativo.</h2>
                <?php endif; ?>
                <?php if(60 < ($aguaCalculada / $solicitud->solicitud_detail->volumen_total) * 100): ?>
                    <h2 class="text-red-500">El volumen total en mL que se genero es mayor al 60% del volumen total de la
                        mezcla. <br>
                        Reajusta el volumen total para generar un nuevo valor para el agua.</h2>
                <?php endif; ?>
            <?php else: ?>
                <p>El usuario no ingreso un volumen total.</p>
                <p>Suma de elementos ingresados por el usuario en mL:
                    <?php echo e(number_format($solicitud->solicitud_detail->suma_volumen, 3, '.', '')); ?></p>
            <?php endif; ?>
        <?php endif; ?>
        <form id="solicitudForm" class="bg-white rounded-lg p-6 shadow-lg">
            <?php echo csrf_field(); ?>

            <?php echo method_field('PUT'); ?>
            <?php if (isset($component)) { $__componentOriginalb24df6adf99a77ed35057e476f61e153 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb24df6adf99a77ed35057e476f61e153 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb24df6adf99a77ed35057e476f61e153)): ?>
<?php $attributes = $__attributesOriginalb24df6adf99a77ed35057e476f61e153; ?>
<?php unset($__attributesOriginalb24df6adf99a77ed35057e476f61e153); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb24df6adf99a77ed35057e476f61e153)): ?>
<?php $component = $__componentOriginalb24df6adf99a77ed35057e476f61e153; ?>
<?php unset($__componentOriginalb24df6adf99a77ed35057e476f61e153); ?>
<?php endif; ?>

            <div class="flex gap-4">
                <div class="mb-4 flex  items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                        Paciente Nombre(s):
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <div class="flex flex-col w-full">
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('nombre_paciente', $solicitud->solicitud_patient->nombre_paciente)).'','name' => 'nombre_paciente','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('nombre_paciente', $solicitud->solicitud_patient->nombre_paciente)).'','name' => 'nombre_paciente','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                        Paciente Apellidos:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <div class="flex flex-col w-full">
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('apellidos_paciente', $solicitud->solicitud_patient->apellidos_paciente)).'','name' => 'apellidos_paciente','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('apellidos_paciente', $solicitud->solicitud_patient->apellidos_paciente)).'','name' => 'apellidos_paciente','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="flex gap-4 ">
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        Servicio:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <div class="flex flex-col w-full">
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('servicio', $solicitud->solicitud_patient->servicio)).'','name' => 'servicio','class' => '','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('servicio', $solicitud->solicitud_patient->servicio)).'','name' => 'servicio','class' => '','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        Cama:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <div class="flex flex-col w-full">
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('cama', $solicitud->solicitud_patient->cama)).'','name' => 'cama','class' => '','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('cama', $solicitud->solicitud_patient->cama)).'','name' => 'cama','class' => '','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        Piso:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <div class="flex flex-col w-full">
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('piso', $solicitud->solicitud_patient->piso)).'','name' => 'piso','class' => '','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('piso', $solicitud->solicitud_patient->piso)).'','name' => 'piso','class' => '','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="flex gap-4">
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        Registro:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('registro', $solicitud->solicitud_patient->registro)).'','name' => 'registro','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('registro', $solicitud->solicitud_patient->registro)).'','name' => 'registro','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                </div>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        Diagnóstico:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('diagnostico', $solicitud->solicitud_patient->diagnostico)).'','name' => 'diagnostico','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('diagnostico', $solicitud->solicitud_patient->diagnostico)).'','name' => 'diagnostico','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="flex gap-4">
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        Peso:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <div class="flex flex-col w-full">
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','value' => ''.e(old('peso', $solicitud->solicitud_patient->peso)).'','step' => '0.001','name' => 'peso','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','value' => ''.e(old('peso', $solicitud->solicitud_patient->peso)).'','step' => '0.001','name' => 'peso','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="mb-4 flex items-stretch gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        Sexo:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['class' => 'w-full','name' => 'sexo','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'sexo','disabled' => true]); ?>
                        <option value="Femenino" <?php if(old('sexo', $solicitud->solicitud_patient->sexo) == 'Femenino'): ?> selected <?php endif; ?>>Femenino</option>
                        <option value="Masculino" <?php if(old('sexo', $solicitud->solicitud_patient->sexo) == 'Masculino'): ?> selected <?php endif; ?>>Masculino</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                </div>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                        Fecha de nacimiento*:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <div class="flex flex-col">
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','value' => ''.e(old('fecha_nacimiento', $solicitud->solicitud_patient->fecha_nacimiento)).'','max' => ''.e(date('Y-m-d')).'','name' => 'fecha_nacimiento','class' => '','placeholder' => '','onchange' => 'calcularEdad(this.value)','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','value' => ''.e(old('fecha_nacimiento', $solicitud->solicitud_patient->fecha_nacimiento)).'','max' => ''.e(date('Y-m-d')).'','name' => 'fecha_nacimiento','class' => '','placeholder' => '','onchange' => 'calcularEdad(this.value)','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>

            </div>
            <div class="flex gap-4">
                <div class="mb-4 flex items-stretch gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                        Vía de administración:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['class' => 'w-full','name' => 'via_administracion','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'via_administracion','disabled' => true]); ?>
                        <option value="Central" <?php if(old('via_administracion', $solicitud->solicitud_detail->via_administracion) == 'Central'): ?> selected <?php endif; ?>>Central</option>
                        <option value="Periférica" <?php if(old('via_administracion', $solicitud->solicitud_detail->via_administracion) == 'Periférica'): ?> selected <?php endif; ?>>Periférica
                        </option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                </div>
                <?php
                    $inputValue = old('velocidad_infusion', $solicitud->solicitud_detail->velocidad_infusion);
                    $hasData = $inputValue ? true : false;
                ?>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                        Tiempo de infusión (h):
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','value' => ''.e($hasData ? '' : old('tiempo_infusion_min', $solicitud->solicitud_detail->tiempo_infusion_min)).'','name' => 'tiempo_infusion_min','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','value' => ''.e($hasData ? '' : old('tiempo_infusion_min', $solicitud->solicitud_detail->tiempo_infusion_min)).'','name' => 'tiempo_infusion_min','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    <!-- Mensaje de error -->

                </div>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                        Velocidad de infusión ml/hr:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','value' => ''.e(old('velocidad_infusion', $solicitud->solicitud_detail->velocidad_infusion)).'','step' => '0.001','name' => 'velocidad_infusion','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','value' => ''.e(old('velocidad_infusion', $solicitud->solicitud_detail->velocidad_infusion)).'','step' => '0.001','name' => 'velocidad_infusion','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>

                </div>
            </div>
            <div class="flex gap-4">
                <div>
                    <div class="mb-4 flex items-baseline gap-2 w-full">
                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                            Sobrellenado (mL):
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','value' => ''.e(old('sobrellenado_ml', $solicitud->solicitud_detail->sobrellenado_ml)).'','step' => '0.0001','name' => 'sobrellenado_ml','class' => 'w-32','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','value' => ''.e(old('sobrellenado_ml', $solicitud->solicitud_detail->sobrellenado_ml)).'','step' => '0.0001','name' => 'sobrellenado_ml','class' => 'w-32','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="mb-4 flex items-baseline gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                        Volumen total (mL):
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','value' => ''.e(old('volumen_total', $solicitud->solicitud_detail->volumen_total)).'','name' => 'volumen_total','step' => '0.0001','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','value' => ''.e(old('volumen_total', $solicitud->solicitud_detail->volumen_total)).'','name' => 'volumen_total','step' => '0.0001','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                </div>
                <div class="mb-4 flex items-stretch gap-2 w-full">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                        NPT:
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['class' => 'w-full','name' => 'npt','id' => 'npt-select','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'npt','id' => 'npt-select','disabled' => true]); ?>

                        
                        <option value="" disabled selected>Seleccionar NPT</option>
                        
                        <option value="INF" <?php if(old('npt', $solicitud->solicitud_detail->npt) == 'INF'): ?> selected <?php endif; ?>>PEDIÁTRICO</option>
                        
                        <option value="ADULT" <?php if(old('npt', $solicitud->solicitud_detail->npt) == 'ADULT'): ?> selected <?php endif; ?>>ADULTO</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>

                </div>
            </div>

            <h2 class="mb-4 font-medium">MACRONUTRIENTES:</h2>
            <hr>
            <div class=" gap-4 items-center">
                <div class="w-full">
                    <h3 class="mt-4 font-medium">AMINOÁCIDOS</h3>
                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 1): ?>
                            <?php
                                $inputValue = old(
                                    'i_' . $input->input_id,
                                    renderInputSection($input->input_id, $inputs_solicitud),
                                );
                                $hasData = $inputValue; // Verifica si existe algún valor en este input
                            ?>

                            <?php if($hasData): ?>
                                
                                <div>
                                    <div class="mb-4 flex items-baseline gap-2 w-full">
                                        <div class="flex w-[40%]">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                                <?php echo e($input->description); ?>:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <div class="flex w-full">
                                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                <span data-original-unidad="<?php echo e($input->unidad); ?>"
                                                    class="unidad-span"><?php echo e($input->unidad); ?>><?php echo e($input->unidad); ?></span>
                                            </div>
                                        </div>

                                        <div class="flex w-[10%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                ML:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <div class="flex w-[20%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                Sobrellenado:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSobrellenadoSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>

                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                                            
                                            <div class="flex w-[15%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Lote:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="flex w-[20%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Caducidad:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 8): ?>
                            <?php
                                $inputValue = old(
                                    'i_' . $input->input_id,
                                    renderInputSection($input->input_id, $inputs_solicitud),
                                );
                                $hasData = $inputValue; // Verifica si existe algún valor en este input
                            ?>

                            <?php if($hasData): ?>
                                
                                <div>
                                    <div class="mb-4 flex items-baseline gap-2 w-full">
                                        <div class="flex w-[40%]">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                                <?php echo e($input->description); ?>:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <div class="flex w-full">
                                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                <span><?php echo e($input->unidad); ?></span>
                                            </div>
                                        </div>
                                        <div class="flex w-[10%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                ML:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <div class="flex w-[20%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                Sobrellenado:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSobrellenadoSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                                            
                                            <div class="flex w-[15%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Lote:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="flex w-[20%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Caducidad:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="w-full">
                    <h3 class="mt-4 font-medium">CARBOHIDRATOS:</h3>
                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 2): ?>
                            <?php
                                $inputValue = old(
                                    'i_' . $input->input_id,
                                    renderInputSection($input->input_id, $inputs_solicitud),
                                );
                                $hasData = $inputValue; // Verifica si existe algún valor
                            ?>

                            <?php if($hasData): ?>
                                
                                <div>
                                    <div class="mb-4 flex items-baseline gap-2 w-full">
                                        <div class="flex w-[40%]">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                                <?php echo e($input->description); ?>:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <div class="flex w-full">
                                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                <span data-original-unidad="<?php echo e($input->unidad); ?>"
                                                    class="unidad-span"><?php echo e($input->unidad); ?>><?php echo e($input->unidad); ?></span>
                                            </div>
                                        </div>
                                        <div class="flex w-[10%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                ML:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <div class="flex w-[20%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                Sobrellenado:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSobrellenadoSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                                            
                                            <div class="flex w-[15%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Lote:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="flex w-[20%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Caducidad:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <H3 class="mt-4 font-medium">LÍPIDOS:</H3>
                    <div class="w-full">
                        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($input->category_id == 3): ?>
                                <?php
                                    $inputValue = old(
                                        'i_' . $input->input_id,
                                        renderInputSection($input->input_id, $inputs_solicitud),
                                    );
                                    $hasData = $inputValue; // Verifica si hay datos
                                ?>

                                <?php if($hasData): ?>
                                    
                                    <div class="w-full">
                                        <div class="mb-4 flex items-baseline gap-2 w-full">
                                            <div class="flex w-[40%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                                    <?php echo e($input->description); ?>:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','class' => 'w-full','value' => ''.e(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud))).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                    <span data-original-unidad="<?php echo e($input->unidad); ?>"
                                                        class="unidad-span"><?php echo e($input->unidad); ?>><?php echo e($input->unidad); ?></span>
                                                </div>
                                            </div>
                                            <div class="flex w-[10%] justify-center items-stretch">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    ML:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <p
                                                    class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                    <?php echo e(renderInputMLSection($input->input_id, $inputs_solicitud)); ?>

                                                </p>
                                            </div>
                                            <div class="flex w-[20%] justify-center items-stretch">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Sobrellenado:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <p
                                                    class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                    <?php echo e(renderInputMLSobrellenadoSection($input->input_id, $inputs_solicitud)); ?>

                                                </p>
                                            </div>
                                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                                                
                                                <div class="flex w-[15%]">
                                                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                        Lote:
                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                    <div class="flex w-full">
                                                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="flex w-[20%]">
                                                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                        Caducidad:
                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                    <div class="flex w-full">
                                                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <h2 class="mb-4 font-medium">ELECTROLITOS</h2>
            <hr>
            <div class="gap-4 items-start mt-4">

                <div class=" grid-flow-col gap-4">
                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 4): ?>
                            <?php
                                $inputValue = old(
                                    'i_' . $input->input_id,
                                    renderInputSection($input->input_id, $inputs_solicitud),
                                );
                                $hasData = $inputValue; // Verifica si existe algún valor en este input
                            ?>

                            <?php if($hasData): ?>
                                
                                <div>
                                    <div class="mb-4 flex items-baseline gap-2 w-full">
                                        
                                        <div class="flex w-[40%]">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                                <?php echo e($input->description); ?>:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <div class="flex w-full">
                                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','class' => 'w-full','value' => ''.e($inputValue).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','class' => 'w-full','value' => ''.e($inputValue).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                <span data-original-unidad="<?php echo e($input->unidad); ?>"
                                                    class="unidad-span-electrolitos"><?php echo e($input->unidad); ?>><?php echo e($input->unidad); ?></span>
                                            </div>
                                        </div>

                                        
                                        <div class="flex w-[10%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                ML:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <div class="flex w-[20%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                Sobrellenado:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSobrellenadoSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                                            
                                            
                                            <div class="flex w-[15%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Lote:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="flex w-[20%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Caducidad:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <h2 class="mb-4 font-medium">ADITIVOS:</h2>
            <hr>
            <div class=" gap-4 items-start mt-4">

                <div class="  gap-4 w-full">

                    <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->category_id == 5): ?>
                            <?php
                                $inputValue = old(
                                    'i_' . $input->input_id,
                                    renderInputSection($input->input_id, $inputs_solicitud),
                                );
                                $hasData = $inputValue; // Verifica si existe algún valor en este input
                            ?>

                            <?php if($hasData): ?>
                                
                                <div>
                                    <div class="mb-4 flex items-baseline gap-2 w-full">
                                        
                                        <div class="flex w-[40%]">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                                <?php echo e($input->description); ?>:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <div class="flex w-full">
                                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'number','class' => 'w-full','value' => ''.e($inputValue).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','class' => 'w-full','value' => ''.e($inputValue).'','name' => 'i_'.e($input->input_id).'','id' => 'i_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                <span><?php echo e($input->unidad); ?></span>
                                            </div>
                                        </div>

                                        <div class="flex w-[10%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                ML:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <div class="flex w-[20%] justify-center items-stretch">
                                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                Sobrellenado:
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                            <p
                                                class="flex border-t-0 border-r-0 border-l-0 border-b-2 border-dotted h-5 w-full pl-2 border-[#6b7280]">
                                                <?php echo e(renderInputMLSobrellenadoSection($input->input_id, $inputs_solicitud)); ?>

                                            </p>
                                        </div>
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                                            
                                            
                                            <div class="flex w-[15%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Lote:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->lote ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="flex w-[20%]">
                                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap font-bold']); ?>
                                                    Caducidad:
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                                <div class="flex w-full">
                                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','placeholder' => '','value' => ''.e($input->medicine->caducidad ?? '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
            <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($input->category_id == 10): ?>
                    <div>
                        <div class="mb-4 flex items-baseline gap-2 w-full">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                <?php echo e($input->description); ?>:
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <div class="flex w-full">
                                <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['class' => 'w-full','name' => 'i_'.e($input->input_id).'','disabled' => true,'id' => 'i_'.e($input->input_id).'_'.e($input->unidad).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'i_'.e($input->input_id).'','disabled' => true,'id' => 'i_'.e($input->input_id).'_'.e($input->unidad).'']); ?>
                                    <option value="0" <?php if(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud)) == '0'): ?> selected <?php endif; ?>>No
                                    </option>
                                    <option value="1" <?php if(old('i_' . $input->input_id, renderInputSection($input->input_id, $inputs_solicitud)) == '1'): ?> selected <?php endif; ?>>Si
                                    </option>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                            </div>
                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                    Lote:
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <div class="flex w-full">
                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','value' => ''.e($input->medicine->lote ?? '').'','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','value' => ''.e($input->medicine->lote ?? '').'','name' => 'l_'.e($input->input_id).'','id' => 'l_'.e($input->input_id).'','step' => '0.0001','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                </div>

                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                                    Caducidad:
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <div class="flex w-full">
                                    
                                    <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','value' => ''.e($input->medicine->caducidad ?? '').'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','class' => '','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','value' => ''.e($input->medicine->caducidad ?? '').'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','id' => 'c_'.e($input->input_id).'','name' => 'c_'.e($input->input_id).'','class' => '','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                
                <div class="flex">
                    <div class="flex items-center w-6/12">

                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                            Bolsa Eva:
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                        <div class="flex w-full">
                            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['class' => 'w-full','name' => 'bolsa_eva','id' => 'bolsa_eva']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','name' => 'bolsa_eva','id' => 'bolsa_eva']); ?>
                                <option value="" disabled selected>Seleccionar Bolsa Eva</option>
                                <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($input->category_id == 6): ?>
                                        <option value="<?php echo e($input->input_id); ?>"
                                            <?php if(old('bolsa_eva', $bolsaSeleccionadaId) == $input->input_id): ?> selected <?php endif; ?>>
                                            <?php echo e($input->description); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                        </div>
                        <!-- Mensaje de error -->
                        <?php $__errorArgs = ['bolsa_eva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <div class="flex items-center w-3/12">
                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                            Lote:
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                        <div class="flex w-full">
                            <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['class' => 'w-full','value' => ''.e(old('lote_bolsa_eva', $loteBolsaEva)).'','name' => 'lote_bolsa_eva','id' => 'lote_bolsa_eva','step' => '0.0001','placeholder' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','value' => ''.e(old('lote_bolsa_eva', $loteBolsaEva)).'','name' => 'lote_bolsa_eva','id' => 'lote_bolsa_eva','step' => '0.0001','placeholder' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                        </div>
                        <?php $__errorArgs = ['lote_bolsa_eva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex items-center w-3/12">
                        <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 whitespace-nowrap']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 whitespace-nowrap']); ?>
                            Caducidad:
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                        <div class="flex w-full">
                            <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'date','value' => ''.e(old('caducidad_bolsa_eva', $caducidadBolsaEva)).'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','name' => 'caducidad_bolsa_eva','id' => 'caducidad_bolsa_eva','class' => '','placeholder' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','value' => ''.e(old('caducidad_bolsa_eva', $caducidadBolsaEva)).'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d')).'','name' => 'caducidad_bolsa_eva','id' => 'caducidad_bolsa_eva','class' => '','placeholder' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                        </div>
                        <?php $__errorArgs = ['caducidad_bolsa_eva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>


            <?php endif; ?>
            <div class="mb-4">
                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                    OBSERVACIONES
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                <textarea class="border-2 border-solid w-full resize-x overflow-auto h-20" name="observaciones" disabled><?php echo e(old('observaciones', $solicitud->solicitud_detail->observaciones)); ?></textarea>
            </div>
            <div class="flex flex-row gap-4 items-start w-full">
                <div class="w-full">
                    <div class="w-full">
                        <div class="mb-4 flex items-baseline gap-2 w-full">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                                Fecha y hora de entrega:
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <div class="flex flex-col w-full">
                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'datetime-local','value' => ''.e(old('fecha_hora_entrega', $solicitud->solicitud_detail->fecha_hora_entrega)).'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')).'','name' => 'fecha_hora_entrega','class' => '','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'datetime-local','value' => ''.e(old('fecha_hora_entrega', $solicitud->solicitud_detail->fecha_hora_entrega)).'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')).'','name' => 'fecha_hora_entrega','class' => '','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="w-full">
                        <div class="w-full">
                            <div class="mb-4 flex items-baseline gap-2 w-full">
                                <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2 font-bold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2 font-bold']); ?>
                                    Fecha y hora de preparación:
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                                <div class="flex flex-col w-full">
                                    <?php if(isset($solicitud->solicitud_aprobada->fecha_hora_preparacion)): ?>
                                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'datetime-local','value' => ''.e(old('fecha_hora_preparacion', $solicitud->solicitud_aprobada->fecha_hora_preparacion)).'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')).'','name' => 'fecha_hora_preparacion','class' => '','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'datetime-local','value' => ''.e(old('fecha_hora_preparacion', $solicitud->solicitud_aprobada->fecha_hora_preparacion)).'','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')).'','name' => 'fecha_hora_preparacion','class' => '','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                    <?php else: ?>
                                        <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['type' => 'datetime-local','value' => '','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')).'','name' => 'fecha_hora_preparacion','class' => '','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'datetime-local','value' => '','min' => ''.e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')).'','name' => 'fecha_hora_preparacion','class' => '','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-full">
                        <div class="mb-4 flex items-baseline gap-2 w-full">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                                Hospital Destino:
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <div class="flex flex-col w-full">
                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('hospital_destino', $solicitud->solicitud_detail->hospital_destino)).'','name' => 'hospital_destino','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('hospital_destino', $solicitud->solicitud_detail->hospital_destino)).'','name' => 'hospital_destino','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="w-full">
                    <div class="w-full">
                        <div class="mb-4 flex items-baseline gap-2 w-full">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                                Nombre del médico:
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <div class="flex flex-col w-full">
                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('nombre_medico', $solicitud->solicitud_detail->nombre_medico)).'','name' => 'nombre_medico','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('nombre_medico', $solicitud->solicitud_detail->nombre_medico)).'','name' => 'nombre_medico','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="w-full">
                        <div class="mb-4 flex items-baseline gap-2 w-full">
                            <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-2']); ?>
                                Cédula profesional:
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                            <div class="flex flex-col w-full">
                                <?php if (isset($component)) { $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-solicitud','data' => ['value' => ''.e(old('cedula', $solicitud->solicitud_detail->cedula)).'','name' => 'cedula','class' => 'w-full','placeholder' => '','disabled' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-solicitud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(old('cedula', $solicitud->solicitud_detail->cedula)).'','name' => 'cedula','class' => 'w-full','placeholder' => '','disabled' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $attributes = $__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__attributesOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142)): ?>
<?php $component = $__componentOriginalb3b9fb33b1ff5c240e18f2295e732142; ?>
<?php unset($__componentOriginalb3b9fb33b1ff5c240e18f2295e732142); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </form>

    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const selectNPT = document.getElementById('npt-select');
                const unidades = document.querySelectorAll('.unidad-span');

                function actualizarUnidades(valorSeleccionado) {

                    unidades.forEach((unidad) => {
                        if (valorSeleccionado === 'ADULT') {
                            unidad.textContent = 'g/día';

                        } else if (valorSeleccionado === 'INF') {
                            unidad.textContent = unidad.getAttribute('data-original-unidad');

                        }
                    });
                }

                // Inicializa las unidades según el valor cargado
                actualizarUnidades(selectNPT.value);

                // Escucha cambios en el select
                selectNPT.addEventListener('change', function() {
                    actualizarUnidades(selectNPT.value);

                });
            });

            document.addEventListener('DOMContentLoaded', function() {
                const selectNPT = document.getElementById('npt-select');
                const unidades = document.querySelectorAll('.unidad-span-electrolitos');

                function actualizarUnidades(valorSeleccionado) {

                    unidades.forEach((unidad) => {
                        if (valorSeleccionado === 'ADULT') {
                            unidad.textContent = 'mEq/día';

                        } else if (valorSeleccionado === 'INF') {
                            unidad.textContent = unidad.getAttribute('data-original-unidad');

                        }
                    });
                }

                // Inicializa las unidades según el valor cargado
                actualizarUnidades(selectNPT.value);

                // Escucha cambios en el select
                selectNPT.addEventListener('change', function() {
                    actualizarUnidades(selectNPT.value);

                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\cbta_app\resources\views/admin/solicitudes/show.blade.php ENDPATH**/ ?>