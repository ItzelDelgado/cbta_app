<div>
    <!-- Aquí pones la estructura HTML para mostrar los detalles -->
    <p>Detalles del registro: <?php echo e($data->created_at); ?></p>
</div><?php /**PATH C:\laragon\www\cbta_app\resources\views/livewire/solicitud-detalles.blade.php ENDPATH**/ ?>