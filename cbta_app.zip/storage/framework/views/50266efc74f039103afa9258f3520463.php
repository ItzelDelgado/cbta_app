<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="mt-2">
        <h1 class="text-2xl font-medium text-gray-800">Lista de Solicitudes</h1>
    </div>

    <div class="flex justify-end mb-4">
        <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
            href="<?php echo e(route('admin.solicitudes.create')); ?>"><i class="fa-solid fa-plus pr-1"></i> Agregar</a>
    </div>

    <div class="relative overflow-x-auto">
        <table id="solicitudesTable" class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <th scope="col" class="px-6 py-3 ">
                            ID
                        </th>
                    <?php endif; ?>
                    <th scope="col" class="px-6 py-3">
                        Hospital
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Paciente
                    </th>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <th scope="col" class="px-6 py-3">
                            Modificar
                        </th>
                    <?php endif; ?>
                    <th scope="col" class="px-6 py-3">
                        Fecha y hora solicitud
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Fecha y hora entrega
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Estado
                    </th>

                    <th scope="col" class="px-6 py-3">
                        Detalles
                    </th>

                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <th scope="col" class="px-6 py-3 text-center">
                            Remisión
                        </th>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                        <th scope="col" class="px-6 py-3">
                            Lote
                        </th>
                    <?php endif; ?>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr
                        class="
                        
                        border-b dark:bg-gray-800 dark:border-gray-700
                    ">
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                            <td scope="row"
                                class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white text-center">
                                <?php echo e($solicitud->id); ?>

                            </td>
                        <?php endif; ?>
                        <td class="px-6 py-4">
                            <?php echo e($solicitud->user->hospital->name); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($solicitud->solicitud_patient->nombre_paciente ?? 'N/A'); ?>

                            <?php echo e($solicitud->solicitud_patient->apellidos_paciente ?? 'N/A'); ?>

                        </td>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                            <td class="px-6 py-4">
                                <?php if($solicitud->is_aprobada == 'Pendiente'): ?>
                                    <div class="flex items-center">
                                        <a class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                                            href="<?php echo e(route('admin.solicitudes.edit', $solicitud)); ?>" >
                                            <i class="fa-solid fa-pen pr-1"></i> Aprobar
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="flex items-center"></div>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <td class="px-6 py-4">
                            <?php echo e($solicitud->created_at); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($solicitud->solicitud_detail->fecha_hora_entrega); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php if($solicitud->is_aprobada == 'Aprobada'): ?>
                                <div class="flex items-center">
                                    <div class="h-2.5 w-2.5 rounded-full bg-green-500 me-2"></div> Aprobada
                                </div>
                            <?php elseif($solicitud->is_aprobada == 'No Aprobada'): ?>
                                <div class="flex items-center">
                                    <div class="h-2.5 w-2.5 rounded-full bg-red-500 me-2"></div> No Aprobada
                                </div>
                            <?php elseif($solicitud->is_aprobada == 'Pendiente'): ?>
                                <div class="flex items-center">
                                    <div class="h-2.5 w-2.5 rounded-full bg-azul-prodifem me-2"></div> Pendiente
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <a href="<?php echo e(route('admin.solicitudes.show', $solicitud)); ?>">
                                    <button
                                        class="text-white bg-azul-prodifem hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-azul-prodifem dark:focus:ring-blue-800"
                                        >
                                        <i class="fa-solid fa-eye pr-1"></i> Ver
                                    </button>
                                </a>
                            </div>
                        </td>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                            <td class="px-6 py-4" style="text-align: center">
                                <?php if(isset($solicitud->solicitud_aprobada)): ?>
                                    <?php echo e($solicitud->solicitud_aprobada->id); ?>

                                <?php else: ?>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasAnyRole', 'Admin|Super Admin')): ?>
                            <td class="px-6 py-4">
                                <?php if(isset($solicitud->solicitud_aprobada)): ?>
                                    <?php echo e($solicitud->solicitud_aprobada->lote); ?>

                                <?php else: ?>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4">
            <?php echo e($solicitudes->links()); ?>

        </div>
    </div>



    <?php $__env->startPush('js'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {

                const initDataTable = () => {
                    const table = document.querySelector('#solicitudesTable');
                    if (table.classList.contains('dataTable-initialized')) {
                        table.DataTable().destroy();
                    }

                    const dataTable = new DataTable(table, {
                        paging: false, // Desactivar paginación de DataTables
                        searching: true,
                        info: false,
                        order: [
                            [0, 'desc']
                        ], // Ordenar la primera columna (ID) de manera descendente
                        language: {
                            lengthMenu: "Mostrar _MENU_ registros por página",
                            zeroRecords: "Nada encontrado - lo siento",
                            info: "Mostrando página _PAGE_ de _PAGES_",
                            infoEmpty: "No hay registros disponibles",
                            infoFiltered: "(filtrado de _MAX_ registros totales)",
                            search: "Buscar:"
                        },
                    });

                    table.classList.add('dataTable-initialized');
                };

                initDataTable();


            });
        </script>
    <?php $__env->stopPush(); ?>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\cbta_app\resources\views/admin/solicitudes/index.blade.php ENDPATH**/ ?>