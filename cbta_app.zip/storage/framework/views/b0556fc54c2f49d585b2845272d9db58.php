<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Remisión</th>
            <th>Lote</th>
            <th>Hospital</th>
            <th>Paciente</th>
            <th>Servicio</th>
            <th>Registro</th>
            <th>Diagnostico</th>
            <th>Edad</th>
            <th>Sexo</th>
            <th>Sobrellenado</th>
            <th>Volumen total</th>
            <th>NPT</th>
            <th>Fecha y hora de solicitud</th>
            <th>Nombre del Médico</th>
            <th>Cedula profesional</th>
            <th>Observaciones</th>
            <th>Aminoácidos pediátricos 10% </th>
            <th>Cloruro de Sodio 0.9%</th>
            <th>Dextrosa 50%</th>
            <th>MCT/LCT 10%</th>
            <th>MCT/LCT 20%</th>
            <th>SMOF 20%</th>
            <th>Cloruro de Sodio (3 mEq/mL Na)</th>
            <th>Acetato de Sodio (4 mEq/mL)</th>
            <th>Fosfato de Sodio (4 mEq/mL)</th>
            <th>Sulfato de Magnesio (0.81 mEq/mL)	</th>
            <th>Cloruro de Potasio (4 mEq/mL)</th>
            <th>Acetato de Potasio (2 mEq/mL)</th>
            <th>Fosfato de Potasio (2 mEq/mL)</th>
            <th>Gluconato de Calcio (0.465 mEq/mL)</th>
            <th>Ácidos Grasos Omega 3 10%</th>
            <th>Albúmina 25% (0.25 g/mL)</th>
            <th>Albúmina 20% (0.20 g/mL)</th>
            <th>Glutamina 20%</th>
            <th>Cromo (4 mcg/mL)</th>
            <th>Heparina (1000 UI/mL)</th>
            <th>L-Carnitina (200 mg/mL)	Insulina (100 UI/mL)	</th>
            <th>Manganeso (100 mcg/mL)</th>
            <th>MVI pediátrico</th>
            <th>Oligoelementos Nulanza</th>
            <th>Oligoelementos Tracefusin</th>
            <th>Ácido Folínico (12.5 mg/mL)</th>
            <th>Selenio (40 mcg/mL)</th>
            <th>Vitamina C (100 mg/mL)</th>
            <th>Vitamina K (10 mg/mL)</th>
            <th>Zinc (1 mg/mL)</th>
            <th>L-Cisteina (50mg/mL)</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($solicitud->id); ?></td>
                
                <td class="px-6 py-4" style="text-align: center">
                    <?php if(isset($solicitud->solicitud_aprobada)): ?>
                        <?php echo e($solicitud->solicitud_aprobada->id); ?>

                    <?php else: ?>
                    <?php endif; ?>
                </td>
                
                <td class="px-6 py-4">
                    <?php if(isset($solicitud->solicitud_aprobada)): ?>
                        <?php echo e($solicitud->solicitud_aprobada->lote); ?>

                    <?php else: ?>
                    <?php endif; ?>
                </td>
                <td><?php echo e($solicitud->user->hospital->name ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_patient->nombre_paciente ?? ''); ?>

                    <?php echo e($solicitud->solicitud_patient->apellidos_paciente ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_patient->servicio ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_patient->registro ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_patient->diagnostico ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_patient->edad ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_patient->sexo ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_detail->sobrellenado_ml ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_detail->volumen_total ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_detail->npt ?? ''); ?></td>
                <td><?php echo e($solicitud->created_at ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_detail->nombre_medico ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_detail->cedula ?? ''); ?></td>
                <td><?php echo e($solicitud->solicitud_detail->observaciones ?? ''); ?></td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 5): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 36): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 8): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 46): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 9): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 10): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 11): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 12): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 13): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 14): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 15): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 16): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 17): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 18): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 19): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 20): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 21): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 22): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 23): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 24): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 25): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 27): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 44): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 29): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 47): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 30): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 31): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 32): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 33): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 34): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

                <td>
                    <?php $__currentLoopData = $solicitud->input; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($input->input_id == 35): ?>
                            <?php echo e($input->valor_ml); ?> ML
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\cbta_app\resources\views/admin/solicitudes/export_excel.blade.php ENDPATH**/ ?>