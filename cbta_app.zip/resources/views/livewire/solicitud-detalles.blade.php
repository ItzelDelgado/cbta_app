<div>
    <!-- Aquí pones la estructura HTML para mostrar los detalles -->
    <p>Detalles del registro: {{ $data->created_at }}</p>
</div>