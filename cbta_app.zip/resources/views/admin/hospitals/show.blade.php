<x-admin-layout>
    <p>Estamos en hospitals show</p>

</x-admin-layout>